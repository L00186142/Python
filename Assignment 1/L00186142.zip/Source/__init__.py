copyright = "© NM 2023" 

__all__ = ['server', 'client1', 'client2', 'client3', 'main']