# Conclusion
What I’ve really learnt on the assignment is it really matters where or what location you run the project. For instance if you were to run the project at the top level of L00186142 then the project wouldn’t run but if you were to run main.py at the Source level inside the project in the project would run. I soon released that Structure and Globally seeing the files really mattered. 

Maybe in the future the structure wouldn’t matter at what level you ran the project but for now it’s a simple project that sends packets from clients and receives them to the server.