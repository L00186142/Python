# Testing

Simple Tests to determine if the network has been set up correctly with the rights IP addresses and port.

Only thing that I ran into trouble was opening the Network file under Network and settings folders. Later I found out that it was vscode and handling the file/ folder structure. It found it hard some times to determine where the file was even though it was at the same sub folder.

Before running the test, you will need to be in the Test folder.
```
\L00186142\Tests\test.py
```

### Test 1
Simple Test to determine that the server ip address and port has the correct and match.

### Test 2
Simple Test to determine the client ip address has the correct one and match.

# How to Run the test
Simply in the cmd line, navigate to the file and run.
```python
python test.py
```
