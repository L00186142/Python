# References
1. Looked for a way to handle the file/ folder location and seen that os module had a good enough way to make this work.
    - https://www.geeksforgeeks.org/os-module-python-examples/
2. When I was testing and running the script in vscode, I experienced a problem with directory and location of file. I found out about sys module and looked into this more. This tool is for searching a location.
    - https://www.geeksforgeeks.org/sys-path-in-python/
3. During the creation of the main python file. I needed a way to open the server and client files simultaneously which wasn’t easy so I looked up the website below and went from there.
    - https://www.datacamp.com/tutorial/python-subprocess
